# Import our pymongo library, which lets us connect our Flask app to our Mongo database.
import pymongo
import pandas as pd

# Create connection variable
conn = 'mongodb://localhost:27017'

# Pass connection to the pymongo instance.
client = pymongo.MongoClient(conn)

# Connect to a database. Will create one if not already available.
db = client.childpop_rate_db
# Drops collection if available to remove duplicates
db.childpop_rate.drop()

# Creates a collection in the database and inserts two documents
df = pd.read_csv('https://raw.githubusercontent.com/DavidMoon-184/Roosters_Project_2/main/FLASK/datasets/population_aged_0_14_years_both_sexes_percent--by--global--time.csv')

def insert_childpop_rate_db():
    for i, row in df.iterrows():
        doc = {
            '_id': f'doc_{i}',
            'global': row["global"],
            'year' : row["time"],
            'Boys Population': row["population_aged_0_14_years_male_percent"],
            'Girls Population': row["population_aged_0_14_years_female_percent"],  
        }
        db.childpop_rate.insert_one(doc)

    print("collection created")

insert_childpop_rate_db()